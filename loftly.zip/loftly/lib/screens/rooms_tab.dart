import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import 'room_screen.dart';

class RoomsTab extends StatelessWidget {
  const RoomsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final rooms = store.rooms;
    return Scaffold(
      body: rooms.isEmpty
          ? const Center(child: Text('Пока нет комнат. Создайте первую!'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 88),
              itemCount: rooms.length,
              itemBuilder: (context, i) => _RoomCard(room: rooms[i]),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateSheet(context),
        icon: const Icon(Icons.add),
        label: const Text('Создать комнату'),
      ),
    );
  }

  void _showCreateSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const _CreateRoomSheet(),
    );
  }
}

class _RoomCard extends StatelessWidget {
  final Room room;
  const _RoomCard({required this.room});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final owner = store.users[room.ownerId]!;
    final online = store.onlineCount(room.id);
    final mine = room.ownerId == 'me';
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => RoomScreen(roomId: room.id)),
        ),
        child: Row(
          children: [
            Container(
              width: 84,
              height: 84,
              color: room.floorColor,
              child: Icon(
                room.isPublic ? Icons.weekend : Icons.lock,
                color: Colors.white,
                size: 36,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(room.name,
                        style: Theme.of(context).textTheme.titleMedium,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text(mine ? 'Ваша комната' : 'Хозяин: ${owner.name}',
                        style: Theme.of(context).textTheme.bodySmall),
                    const SizedBox(height: 4),
                    Row(children: [
                      const Icon(Icons.circle, size: 10, color: Colors.green),
                      const SizedBox(width: 4),
                      Text('$online в комнате'),
                      if (!room.isPublic) ...[
                        const SizedBox(width: 8),
                        const Text('· только по приглашению'),
                      ],
                    ]),
                  ],
                ),
              ),
            ),
            if (mine)
              IconButton(
                tooltip: 'Удалить комнату',
                icon: const Icon(Icons.delete_outline),
                onPressed: () => store.deleteRoom(room.id),
              ),
          ],
        ),
      ),
    );
  }
}

class _CreateRoomSheet extends StatefulWidget {
  const _CreateRoomSheet();

  @override
  State<_CreateRoomSheet> createState() => _CreateRoomSheetState();
}

class _CreateRoomSheetState extends State<_CreateRoomSheet> {
  final _name = TextEditingController();
  int _floor = 0;
  bool _public = true;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return Padding(
      padding: EdgeInsets.fromLTRB(
        16, 0, 16, MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Новая комната', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          TextField(
            controller: _name,
            maxLength: 30,
            decoration: const InputDecoration(
              labelText: 'Название',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          const Text('Пол'),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            children: [
              for (var i = 0; i < floorColors.length; i++)
                GestureDetector(
                  onTap: () => setState(() => _floor = i),
                  child: CircleAvatar(
                    backgroundColor: floorColors[i],
                    radius: 18,
                    child: _floor == i
                        ? const Icon(Icons.check, color: Colors.white)
                        : null,
                  ),
                ),
            ],
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Открытая комната'),
            subtitle: const Text('Закрытая — только по приглашению'),
            value: _public,
            onChanged: (v) => setState(() => _public = v),
          ),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () {
                final name = _name.text.trim();
                if (name.isEmpty) return;
                final room = store.createRoom(
                  name: name,
                  floor: _floor,
                  isPublic: _public,
                );
                final nav = Navigator.of(context);
                nav.pop();
                nav.push(MaterialPageRoute<void>(
                  builder: (_) => RoomScreen(roomId: room.id),
                ));
              },
              child: const Text('Создать и войти'),
            ),
          ),
        ],
      ),
    );
  }
}
