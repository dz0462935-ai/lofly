import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../widgets/avatar.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final me = store.me;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(child: AvatarFigure(user: me, size: 96)),
        const SizedBox(height: 8),
        Center(
          child: TextButton.icon(
            onPressed: () => _rename(context, store),
            icon: const Icon(Icons.edit, size: 18),
            label: Text(me.name, style: const TextStyle(fontSize: 20)),
          ),
        ),
        const SizedBox(height: 16),
        const Text('Одежда'),
        const SizedBox(height: 8),
        _ColorRow(
          colors: outfitColors,
          selected: me.outfit,
          onPick: (c) => store.updateProfile(outfit: c),
        ),
        const SizedBox(height: 16),
        const Text('Цвет кожи'),
        const SizedBox(height: 8),
        _ColorRow(
          colors: skinTones,
          selected: me.skin,
          onPick: (c) => store.updateProfile(skin: c),
        ),
        const SizedBox(height: 16),
        const Text('Аксессуар'),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            for (var i = 0; i < hats.length; i++)
              ChoiceChip(
                label: Text(hats[i].isEmpty ? 'Нет' : hats[i],
                    style: const TextStyle(fontSize: 18)),
                selected: me.hat == i,
                onSelected: (_) => store.updateProfile(hat: i),
              ),
          ],
        ),
      ],
    );
  }

  void _rename(BuildContext context, AppStore store) {
    final c = TextEditingController(text: store.me.name);
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Ваше имя'),
        content: TextField(controller: c, maxLength: 20, autofocus: true),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () {
              store.updateProfile(name: c.text);
              Navigator.pop(ctx);
            },
            child: const Text('Сохранить'),
          ),
        ],
      ),
    ).then((_) => c.dispose());
  }
}

class _ColorRow extends StatelessWidget {
  final List<Color> colors;
  final Color selected;
  final ValueChanged<Color> onPick;

  const _ColorRow({
    required this.colors,
    required this.selected,
    required this.onPick,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        for (final c in colors)
          GestureDetector(
            onTap: () => onPick(c),
            child: CircleAvatar(
              radius: 18,
              backgroundColor: c,
              child: c == selected
                  ? const Icon(Icons.check, color: Colors.white)
                  : null,
            ),
          ),
      ],
    );
  }
}
