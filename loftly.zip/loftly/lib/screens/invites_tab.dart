import 'package:flutter/material.dart';

import '../store.dart';
import '../widgets/avatar.dart';
import 'room_screen.dart';

class InvitesTab extends StatelessWidget {
  const InvitesTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final invites = store.invites;
    if (invites.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Приглашений нет. Когда друг позовёт вас в комнату, оно появится здесь.',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: invites.length,
      itemBuilder: (context, i) {
        final inv = invites[i];
        final from = store.users[inv.fromId]!;
        final room = store.roomById(inv.roomId);
        if (room == null) return const SizedBox.shrink();
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  AvatarBadge(user: from),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text.rich(TextSpan(children: [
                      TextSpan(
                        text: from.name,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const TextSpan(text: ' зовёт вас в комнату '),
                      TextSpan(
                        text: '«${room.name}»',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ])),
                  ),
                ]),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () => store.declineInvite(inv),
                      child: const Text('Отклонить'),
                    ),
                    const SizedBox(width: 8),
                    FilledButton(
                      onPressed: () {
                        final r = store.acceptInvite(inv);
                        if (r == null) return;
                        Navigator.of(context).push(MaterialPageRoute<void>(
                          builder: (_) => RoomScreen(roomId: r.id),
                        ));
                      },
                      child: const Text('Принять'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
