import 'package:flutter/material.dart';

import '../store.dart';
import 'friends_tab.dart';
import 'invites_tab.dart';
import 'profile_tab.dart';
import 'rooms_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  static const _titles = ['Комнаты', 'Друзья', 'Приглашения', 'Профиль'];
  static const _tabs = <Widget>[
    RoomsTab(),
    FriendsTab(),
    InvitesTab(),
    ProfileTab(),
  ];

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(_titles[_index])),
      body: _tabs[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          const NavigationDestination(
            icon: Icon(Icons.meeting_room_outlined),
            selectedIcon: Icon(Icons.meeting_room),
            label: 'Комнаты',
          ),
          NavigationDestination(
            icon: Badge(
              label: Text('${store.incomingRequests.length}'),
              isLabelVisible: store.incomingRequests.isNotEmpty,
              child: const Icon(Icons.group_outlined),
            ),
            selectedIcon: const Icon(Icons.group),
            label: 'Друзья',
          ),
          NavigationDestination(
            icon: Badge(
              label: Text('${store.invites.length}'),
              isLabelVisible: store.invites.isNotEmpty,
              child: const Icon(Icons.mail_outline),
            ),
            selectedIcon: const Icon(Icons.mail),
            label: 'Приглашения',
          ),
          const NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Профиль',
          ),
        ],
      ),
    );
  }
}
