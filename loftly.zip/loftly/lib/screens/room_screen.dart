import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../widgets/avatar.dart';
import '../widgets/user_sheet.dart';

class RoomScreen extends StatefulWidget {
  final String roomId;
  const RoomScreen({super.key, required this.roomId});

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  late AppStore _store;
  bool _entered = false;
  final _text = TextEditingController();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _store = StoreScope.of(context);
    if (!_entered) {
      _entered = true;
      _store.enterRoom(widget.roomId);
    }
  }

  @override
  void dispose() {
    _store.leaveRoom();
    _text.dispose();
    super.dispose();
  }

  void _send() {
    _store.sendMessage(_text.text);
    _text.clear();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final room = store.roomById(widget.roomId);
    if (room == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: Text('Комната удалена')),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(room.name),
        actions: [
          IconButton(
            tooltip: 'Пригласить друга',
            icon: const Icon(Icons.person_add_alt_1),
            onPressed: () => _showInviteSheet(context, room),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: _RoomView(room: room)),
          _ChatPanel(roomId: room.id, controller: _text, onSend: _send),
        ],
      ),
    );
  }

  void _showInviteSheet(BuildContext context, Room room) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (_) => _InviteSheet(roomId: room.id),
    );
  }
}

class _RoomView extends StatelessWidget {
  final Room room;
  const _RoomView({required this.room});

  static const double _avatarSize = 40;
  static const double _slotW = 96;
  static const double _slotH = 118;

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final occ = store.occupants(room.id);
    final entries = occ.entries.toList()
      ..sort((a, b) => a.value.dy.compareTo(b.value.dy));

    return LayoutBuilder(builder: (context, c) {
      final w = c.maxWidth;
      final h = c.maxHeight;
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (d) => store.moveMe(
          Offset(d.localPosition.dx / w, d.localPosition.dy / h),
        ),
        child: Stack(
          clipBehavior: Clip.hardEdge,
          children: [
            Positioned.fill(
              child: CustomPaint(painter: _FloorPainter(room.floorColor)),
            ),
            for (final e in entries)
              AnimatedPositioned(
                key: ValueKey(e.key),
                duration: const Duration(milliseconds: 700),
                curve: Curves.easeInOut,
                left: e.value.dx * w - _slotW / 2,
                top: e.value.dy * h - _slotH,
                width: _slotW,
                height: _slotH,
                child: _AvatarSlot(
                  user: store.users[e.key]!,
                  emote: store.emotes[e.key],
                  isMe: e.key == 'me',
                ),
              ),
          ],
        ),
      );
    });
  }
}

class _AvatarSlot extends StatelessWidget {
  final User user;
  final String? emote;
  final bool isMe;

  const _AvatarSlot({required this.user, this.emote, required this.isMe});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (!isMe) showUserSheet(context, user.id);
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          if (emote != null)
            Text(emote!, style: const TextStyle(fontSize: 26)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
            decoration: BoxDecoration(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              user.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: isMe ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
          const SizedBox(height: 2),
          AvatarFigure(user: user, size: _RoomView._avatarSize),
        ],
      ),
    );
  }
}

class _FloorPainter extends CustomPainter {
  final Color base;
  _FloorPainter(this.base);

  @override
  void paint(Canvas canvas, Size size) {
    final wallH = size.height * 0.2;
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, wallH),
      Paint()..color = Color.alphaBlend(Colors.black26, base),
    );
    const t = 44.0;
    final a = Paint()..color = base;
    final b = Paint()..color = Color.alphaBlend(Colors.white24, base);
    var row = 0;
    for (var y = wallH; y < size.height; y += t, row++) {
      var col = 0;
      for (var x = 0.0; x < size.width; x += t, col++) {
        canvas.drawRect(
          Rect.fromLTWH(x, y, t, t),
          (row + col).isEven ? a : b,
        );
      }
    }
  }

  @override
  bool shouldRepaint(_FloorPainter old) => old.base != base;
}

class _ChatPanel extends StatelessWidget {
  final String roomId;
  final TextEditingController controller;
  final VoidCallback onSend;

  const _ChatPanel({
    required this.roomId,
    required this.controller,
    required this.onSend,
  });

  static const _emotes = ['👋', '😀', '😂', '❤️', '🎉', '😎'];

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final all = store.chat(roomId);
    final last = all.length > 30 ? all.sublist(all.length - 30) : all;
    return Material(
      elevation: 8,
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 110,
              child: ListView.builder(
                reverse: true,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                itemCount: last.length,
                itemBuilder: (context, i) {
                  final m = last[last.length - 1 - i];
                  if (m.isSystem) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Text(
                        m.text,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontStyle: FontStyle.italic,
                          fontSize: 12,
                          color: Theme.of(context).hintColor,
                        ),
                      ),
                    );
                  }
                  final u = store.users[m.userId]!;
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Text.rich(TextSpan(children: [
                      TextSpan(
                        text: '${u.name}: ',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: u.outfit,
                        ),
                      ),
                      TextSpan(text: m.text),
                    ])),
                  );
                },
              ),
            ),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                children: [
                  for (final e in _emotes)
                    TextButton(
                      onPressed: () => store.sendEmote(e),
                      child: Text(e, style: const TextStyle(fontSize: 22)),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 4, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => onSend(),
                      decoration: const InputDecoration(
                        hintText: 'Сообщение…',
                        isDense: true,
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(onPressed: onSend, icon: const Icon(Icons.send)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InviteSheet extends StatelessWidget {
  final String roomId;
  const _InviteSheet({required this.roomId});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final inRoom = store.occupants(roomId);
    final candidates =
        store.friendList.where((f) => !inRoom.containsKey(f.id)).toList();
    return SafeArea(
      child: candidates.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(24),
              child: Text('Все ваши друзья уже здесь или у вас пока нет друзей.'),
            )
          : ListView(
              shrinkWrap: true,
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                  child: Text('Пригласить друга',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                ),
                for (final f in candidates)
                  ListTile(
                    leading: AvatarBadge(user: f),
                    title: Text(f.name),
                    trailing: FilledButton.tonal(
                      onPressed: () {
                        store.inviteFriend(f.id);
                        Navigator.of(context).pop();
                      },
                      child: const Text('Пригласить'),
                    ),
                  ),
              ],
            ),
    );
  }
}
