import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import 'models.dart';

const _phrases = [
  'Привет всем! 👋',
  'Классная комната',
  'Кто на вечеринку?',
  'Ха-ха, это жиза',
  'Как дела?',
  'Добавляйтесь в друзья!',
  'Музыка огонь 🎶',
  'Я ненадолго',
  'Заходите ещё!',
];

/// Локальное «псевдо-серверное» состояние приложения.
/// Позже его можно заменить реальным бэкендом (Firebase / Supabase / свой сервер),
/// сохранив публичный интерфейс.
class AppStore extends ChangeNotifier {
  AppStore() {
    _seed();
    _scheduleIncomingInvite(1);
  }

  final _rng = Random();
  late User me;
  final Map<String, User> users = {};
  final Set<String> friends = {};
  final List<String> incomingRequests = [];
  final Set<String> outgoingRequests = {};
  final List<Room> rooms = [];
  final List<Invite> invites = [];
  final Map<String, String> emotes = {};

  final Map<String, Map<String, Offset>> _occupants = {};
  final Map<String, List<ChatMessage>> _chat = {};
  final List<Timer> _timers = [];
  Timer? _tick;
  String? currentRoomId;
  bool _disposed = false;
  int _idSeq = 0;

  String _newId(String prefix) => '$prefix${_idSeq++}';

  void _seed() {
    me = User(
      id: 'me',
      name: 'Вы',
      outfit: outfitColors[0],
      skin: skinTones[1],
    );
    users['me'] = me;
    const names = [
      'Алиса', 'Макс', 'Соня', 'Тимур', 'Лера', 'Данил', 'Ника', 'Артём',
    ];
    for (var i = 0; i < names.length; i++) {
      users['u$i'] = User(
        id: 'u$i',
        name: names[i],
        outfit: outfitColors[(i + 1) % outfitColors.length],
        skin: skinTones[i % skinTones.length],
        hat: i % hats.length,
      );
    }
    friends.addAll(['u0', 'u1', 'u2']);
    incomingRequests.add('u3');

    rooms.addAll([
      Room(id: 'r0', name: 'Крыша на закате', ownerId: 'u0', floor: 1),
      Room(id: 'r1', name: 'Кофейня', ownerId: 'u1', floor: 2),
      Room(id: 'r2', name: 'Танцпол', ownerId: 'u4', floor: 4),
      Room(id: 'r3', name: 'Моя комната', ownerId: 'me', floor: 0, isPublic: false),
    ]);

    for (final r in rooms) {
      final occ = <String, Offset>{};
      final candidates = users.keys.where((k) => k != 'me').toList()
        ..shuffle(_rng);
      final n = r.ownerId == 'me' ? 0 : 1 + _rng.nextInt(3);
      for (final id in candidates.take(n)) {
        occ[id] = _randomSpot();
      }
      _occupants[r.id] = occ;
      _chat[r.id] = [ChatMessage.system('Добро пожаловать в «${r.name}»')];
    }

    invites.add(Invite(id: _newId('i'), roomId: 'r0', fromId: 'u0'));
  }

  Offset _randomSpot() =>
      Offset(0.1 + _rng.nextDouble() * 0.8, 0.3 + _rng.nextDouble() * 0.65);

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  void _later(Duration d, void Function() f) {
    _timers.add(Timer(d, () {
      if (!_disposed) f();
    }));
  }

  // ---------- Запросы ----------

  Map<String, Offset> occupants(String roomId) => _occupants[roomId] ?? {};
  List<ChatMessage> chat(String roomId) => _chat[roomId] ?? [];
  int onlineCount(String roomId) => occupants(roomId).length;
  Room? roomById(String id) {
    for (final r in rooms) {
      if (r.id == id) return r;
    }
    return null;
  }

  String? locationOf(String userId) {
    for (final e in _occupants.entries) {
      if (e.value.containsKey(userId)) return e.key;
    }
    return null;
  }

  List<User> get friendList =>
      friends.map((id) => users[id]!).toList()
        ..sort((a, b) => a.name.compareTo(b.name));

  List<User> get discoverable => users.values
      .where((u) =>
          u.id != 'me' &&
          !friends.contains(u.id) &&
          !outgoingRequests.contains(u.id))
      .toList();

  // ---------- Комнаты ----------

  Room createRoom({
    required String name,
    required int floor,
    required bool isPublic,
  }) {
    final room = Room(
      id: _newId('r'),
      name: name,
      ownerId: 'me',
      floor: floor,
      isPublic: isPublic,
    );
    rooms.insert(0, room);
    _occupants[room.id] = {};
    _chat[room.id] = [ChatMessage.system('Комната создана')];
    _notify();
    return room;
  }

  void deleteRoom(String id) {
    rooms.removeWhere((r) => r.id == id && r.ownerId == 'me');
    _occupants.remove(id);
    _chat.remove(id);
    invites.removeWhere((i) => i.roomId == id);
    _notify();
  }

  void enterRoom(String roomId) {
    currentRoomId = roomId;
    final occ = _occupants.putIfAbsent(roomId, () => {});
    occ['me'] = const Offset(0.5, 0.85);
    _chat.putIfAbsent(roomId, () => []).add(ChatMessage.system('Вы вошли в комнату'));
    _tick?.cancel();
    _tick = Timer.periodic(const Duration(seconds: 3), (_) => _botTick());
  }

  void leaveRoom() {
    final id = currentRoomId;
    if (id == null) return;
    _occupants[id]?.remove('me');
    emotes.clear();
    currentRoomId = null;
    _tick?.cancel();
    _tick = null;
    Future.microtask(_notify);
  }

  void _botTick() {
    final id = currentRoomId;
    if (id == null) return;
    final occ = _occupants[id];
    if (occ == null) return;
    final bots = occ.keys.where((k) => k != 'me').toList();
    for (final b in bots) {
      final r = _rng.nextDouble();
      if (r < 0.45) {
        occ[b] = _randomSpot();
      } else if (r < 0.55) {
        _say(id, b, _phrases[_rng.nextInt(_phrases.length)]);
      } else if (r < 0.6) {
        occ.remove(b);
        _system(id, '${users[b]!.name} вышел(а)');
      }
    }
    if (occ.length < 6 && _rng.nextDouble() < 0.3) {
      final cand = users.keys
          .where((k) => k != 'me' && !occ.containsKey(k))
          .toList();
      if (cand.isNotEmpty) {
        final b = cand[_rng.nextInt(cand.length)];
        _removeFromAllRooms(b);
        occ[b] = _randomSpot();
        _system(id, '${users[b]!.name} зашёл(ла)');
      }
    }
    _notify();
  }

  void _removeFromAllRooms(String userId) {
    for (final m in _occupants.values) {
      m.remove(userId);
    }
  }

  void _say(String roomId, String userId, String text) {
    final list = _chat.putIfAbsent(roomId, () => []);
    list.add(ChatMessage(userId, text));
    if (list.length > 200) list.removeRange(0, list.length - 200);
  }

  void _system(String roomId, String text) {
    _chat.putIfAbsent(roomId, () => []).add(ChatMessage.system(text));
  }

  void moveMe(Offset p) {
    final id = currentRoomId;
    if (id == null) return;
    _occupants[id]?['me'] = Offset(
      p.dx.clamp(0.08, 0.92).toDouble(),
      p.dy.clamp(0.25, 0.96).toDouble(),
    );
    _notify();
  }

  void sendMessage(String text) {
    final id = currentRoomId;
    final t = text.trim();
    if (id == null || t.isEmpty) return;
    _say(id, 'me', t);
    _notify();
    if (_rng.nextDouble() < 0.4) {
      _later(const Duration(milliseconds: 1500), () {
        final occ = _occupants[id];
        if (currentRoomId != id || occ == null) return;
        final bots = occ.keys.where((k) => k != 'me').toList();
        if (bots.isEmpty) return;
        _say(id, bots[_rng.nextInt(bots.length)],
            _phrases[_rng.nextInt(_phrases.length)]);
        _notify();
      });
    }
  }

  void sendEmote(String emoji) {
    if (currentRoomId == null) return;
    emotes['me'] = emoji;
    _notify();
    _later(const Duration(seconds: 2), () {
      if (emotes['me'] == emoji) {
        emotes.remove('me');
        _notify();
      }
    });
  }

  // ---------- Приглашения ----------

  /// Приглашает друга в текущую комнату. В прототипе друг «принимает» через 3 секунды.
  void inviteFriend(String friendId) {
    final id = currentRoomId;
    if (id == null) return;
    _system(id, 'Вы пригласили ${users[friendId]!.name}');
    _later(const Duration(seconds: 3), () {
      final occ = _occupants[id];
      if (currentRoomId == id && occ != null && !occ.containsKey(friendId)) {
        _removeFromAllRooms(friendId);
        occ[friendId] = _randomSpot();
        _system(id, '${users[friendId]!.name} принял(а) приглашение');
        _notify();
      }
    });
    _notify();
  }

  Room? acceptInvite(Invite inv) {
    invites.removeWhere((i) => i.id == inv.id);
    _notify();
    return roomById(inv.roomId);
  }

  void declineInvite(Invite inv) {
    invites.removeWhere((i) => i.id == inv.id);
    _notify();
  }

  void _scheduleIncomingInvite(int attempt) {
    if (attempt > 5) return;
    _later(Duration(seconds: 20 + attempt * 10), () {
      final from = friends.toList();
      final open = rooms.where((r) => r.isPublic).toList();
      if (from.isNotEmpty && open.isNotEmpty) {
        invites.add(Invite(
          id: _newId('i'),
          roomId: open[_rng.nextInt(open.length)].id,
          fromId: from[_rng.nextInt(from.length)],
        ));
        _notify();
      }
      _scheduleIncomingInvite(attempt + 1);
    });
  }

  // ---------- Друзья ----------

  void acceptRequest(String userId) {
    incomingRequests.remove(userId);
    friends.add(userId);
    _notify();
  }

  void declineRequest(String userId) {
    incomingRequests.remove(userId);
    _notify();
  }

  /// В прототипе запрос «принимается» автоматически через 2 секунды.
  void sendRequest(String userId) {
    outgoingRequests.add(userId);
    _notify();
    _later(const Duration(seconds: 2), () {
      outgoingRequests.remove(userId);
      friends.add(userId);
      _notify();
    });
  }

  void removeFriend(String userId) {
    friends.remove(userId);
    _notify();
  }

  // ---------- Профиль ----------

  void updateProfile({String? name, Color? outfit, Color? skin, int? hat}) {
    if (name != null && name.trim().isNotEmpty) me.name = name.trim();
    if (outfit != null) me.outfit = outfit;
    if (skin != null) me.skin = skin;
    if (hat != null) me.hat = hat;
    _notify();
  }

  @override
  void dispose() {
    _disposed = true;
    _tick?.cancel();
    for (final t in _timers) {
      t.cancel();
    }
    super.dispose();
  }
}

class StoreScope extends InheritedNotifier<AppStore> {
  const StoreScope({super.key, required AppStore store, required super.child})
      : super(notifier: store);

  static AppStore of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<StoreScope>()!.notifier!;
}
