import 'package:flutter/material.dart';

const List<Color> outfitColors = [
  Color(0xFF7E57C2),
  Color(0xFFEF5350),
  Color(0xFF26A69A),
  Color(0xFFFFA726),
  Color(0xFF42A5F5),
  Color(0xFFEC407A),
  Color(0xFF66BB6A),
  Color(0xFF8D6E63),
];

const List<Color> skinTones = [
  Color(0xFFFFE0BD),
  Color(0xFFF1C27D),
  Color(0xFFC68642),
  Color(0xFF8D5524),
];

/// Эмодзи-аксессуары над головой аватара (0 — без аксессуара).
const List<String> hats = ['', '🎩', '👑', '🎀', '🧢'];

const List<Color> floorColors = [
  Color(0xFFB39DDB),
  Color(0xFF80CBC4),
  Color(0xFFFFCC80),
  Color(0xFF90CAF9),
  Color(0xFFF48FB1),
];

class User {
  final String id;
  String name;
  Color outfit;
  Color skin;
  int hat;

  User({
    required this.id,
    required this.name,
    required this.outfit,
    required this.skin,
    this.hat = 0,
  });
}

class Room {
  final String id;
  String name;
  final String ownerId;
  int floor;
  bool isPublic;

  Room({
    required this.id,
    required this.name,
    required this.ownerId,
    this.floor = 0,
    this.isPublic = true,
  });

  Color get floorColor => floorColors[floor % floorColors.length];
}

class Invite {
  final String id;
  final String roomId;
  final String fromId;
  final DateTime time;

  Invite({required this.id, required this.roomId, required this.fromId})
      : time = DateTime.now();
}

class ChatMessage {
  /// null — системное сообщение.
  final String? userId;
  final String text;
  final DateTime time;

  ChatMessage(this.userId, this.text) : time = DateTime.now();
  ChatMessage.system(String text) : this(null, text);

  bool get isSystem => userId == null;
}
