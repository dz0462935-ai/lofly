import 'package:flutter/material.dart';

import '../store.dart';
import 'avatar.dart';

/// Карточка пользователя: профиль и действия (добавить в друзья).
void showUserSheet(BuildContext context, String userId) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (_) => _UserSheet(userId: userId),
  );
}

class _UserSheet extends StatelessWidget {
  final String userId;
  const _UserSheet({required this.userId});

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    final user = store.users[userId]!;
    final isFriend = store.friends.contains(userId);
    final pending = store.outgoingRequests.contains(userId);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AvatarFigure(user: user, size: 64),
            const SizedBox(height: 8),
            Text(user.name, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: isFriend
                  ? const FilledButton.tonal(
                      onPressed: null,
                      child: Text('Уже в друзьях'),
                    )
                  : FilledButton(
                      onPressed: pending
                          ? null
                          : () {
                              store.sendRequest(userId);
                              Navigator.of(context).pop();
                            },
                      child: Text(pending ? 'Запрос отправлен' : 'Добавить в друзья'),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
