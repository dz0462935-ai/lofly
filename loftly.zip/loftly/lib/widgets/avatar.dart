import 'package:flutter/material.dart';

import '../models.dart';

/// Аватар-«фигурка» для комнаты: голова, тело, аксессуар.
class AvatarFigure extends StatelessWidget {
  final User user;
  final double size;

  const AvatarFigure({super.key, required this.user, this.size = 40});

  @override
  Widget build(BuildContext context) {
    final bodyH = size * 0.8;
    final headD = size * 0.6;
    return SizedBox(
      width: size,
      height: size * 1.6,
      child: Stack(
        alignment: Alignment.bottomCenter,
        clipBehavior: Clip.none,
        children: [
          Container(
            width: size * 0.7,
            height: bodyH,
            decoration: BoxDecoration(
              color: user.outfit,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(size * 0.35),
                bottom: Radius.circular(size * 0.1),
              ),
            ),
          ),
          Positioned(
            bottom: bodyH * 0.85,
            child: Container(
              width: headD,
              height: headD,
              decoration: BoxDecoration(color: user.skin, shape: BoxShape.circle),
            ),
          ),
          if (user.hat > 0)
            Positioned(
              bottom: bodyH * 0.85 + headD * 0.75,
              child: Text(hats[user.hat], style: TextStyle(fontSize: size * 0.45)),
            ),
        ],
      ),
    );
  }
}

/// Маленький круглый аватар для списков.
class AvatarBadge extends StatelessWidget {
  final User user;
  final double radius;

  const AvatarBadge({super.key, required this.user, this.radius = 20});

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundColor: user.outfit,
      child: Text(
        user.name.isEmpty ? '?' : user.name.characters.first.toUpperCase(),
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: radius * 0.9,
        ),
      ),
    );
  }
}
